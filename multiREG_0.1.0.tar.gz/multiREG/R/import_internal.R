#' @keywords internal
convolve = setupConvolve = getFromNamespace('setupConvolve', 'gimme')