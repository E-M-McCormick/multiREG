#' @keywords internal
setupConvolve = getFromNamespace("setupConvolve", "gimme")